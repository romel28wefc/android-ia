package com.example.relojapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import android.media.MediaPlayer
import androidx.appcompat.app.AlertDialog
import android.os.CountDownTimer
import android.content.SharedPreferences
import androidx.preference.PreferenceManager

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvTimer: TextView
    private lateinit var tvScore: TextView
    private lateinit var tvWinStreak: TextView
    private lateinit var buttons: Array<Button>
    private var playerXTurn = true
    private var gameActive = true
    private var moveCount = 0
    private var playerXScore = 0
    private var playerOScore = 0
    private var currentWinStreak = 0
    private var bestWinStreak = 0
    private var timePerTurn = 10000L // 10 segundos por turno
    private lateinit var turnTimer: CountDownTimer
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var sharedPreferences: SharedPreferences

    private val board = Array(3) { IntArray(3) }

    companion object {
        private const val EMPTY = 0
        private const val PLAYER_X = 1
        private const val PLAYER_O = 2
        private val WINNING_SEQUENCES = arrayOf(
            intArrayOf(0, 1, 2),
            intArrayOf(3, 4, 5),
            intArrayOf(6, 7, 8),
            intArrayOf(0, 3, 6),
            intArrayOf(1, 4, 7),
            intArrayOf(2, 5, 8),
            intArrayOf(0, 4, 8),
            intArrayOf(2, 4, 6)
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        loadGameStats()
        initializeViews()
        initializeBoard()
        setButtonListeners()
        initializeSound()
    }

    private fun initializeViews() {
        tvStatus = findViewById(R.id.tvStatus)
        tvTimer = findViewById(R.id.tvTimer)
        tvScore = findViewById(R.id.tvScore)
        tvWinStreak = findViewById(R.id.tvWinStreak)
        buttons = arrayOf(
            findViewById(R.id.btn1), findViewById(R.id.btn2), findViewById(R.id.btn3),
            findViewById(R.id.btn4), findViewById(R.id.btn5), findViewById(R.id.btn6),
            findViewById(R.id.btn7), findViewById(R.id.btn8), findViewById(R.id.btn9)
        )

        buttons.forEach { button ->
            button.setBackgroundColor(ContextCompat.getColor(this, android.R.color.white))
            button.setTextColor(ContextCompat.getColor(this, android.R.color.black))
        }

        updateScoreDisplay()
        updateWinStreakDisplay()
    }

    private fun initializeSound() {
        // No inicializamos el MediaPlayer si no hay sonido
        mediaPlayer = MediaPlayer()  // Crear una instancia vacía
    }

    private fun loadGameStats() {
        playerXScore = sharedPreferences.getInt("player_x_score", 0)
        playerOScore = sharedPreferences.getInt("player_o_score", 0)
        bestWinStreak = sharedPreferences.getInt("best_win_streak", 0)
    }

    private fun saveGameStats() {
        sharedPreferences.edit().apply {
            putInt("player_x_score", playerXScore)
            putInt("player_o_score", playerOScore)
            putInt("best_win_streak", bestWinStreak)
            apply()
        }
    }

    private fun startTurnTimer() {
        turnTimer = object : CountDownTimer(timePerTurn, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                tvTimer.text = "Tiempo: ${millisUntilFinished / 1000}s"
                if (millisUntilFinished <= 3000) {
                    tvTimer.setTextColor(ContextCompat.getColor(this@MainActivity, android.R.color.holo_red_light))
                }
            }

            override fun onFinish() {
                timeUp()
            }
        }.start()
    }

    private fun timeUp() {
        if (gameActive) {
            playerXTurn = !playerXTurn
            showToast("¡Tiempo agotado! Turno del siguiente jugador")
            updateStatus()
            startTurnTimer()
        }
    }

    private fun initializeBoard() {
        for (i in 0 until 3) {
            for (j in 0 until 3) {
                board[i][j] = EMPTY
            }
        }
        moveCount = 0
        gameActive = true
        updateStatus()
        startTurnTimer()
    }

    private fun setButtonListeners() {
        buttons.forEach { button ->
            button.setOnClickListener {
                if (gameActive) {
                    onButtonClick(button)
                    // Añadir animación al botón
                    button.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_click))
                    // Removemos la línea del mediaPlayer.start()
                }
            }
        }
    }

    private fun onButtonClick(button: Button) {
        val tag = button.tag.toString().toIntOrNull() ?: return
        if (tag !in 0..8) return

        val row = tag / 3
        val col = tag % 3

        if (board[row][col] != EMPTY) {
            showToast("¡Casilla ocupada!")
            return
        }

        moveCount++
        updateButton(button, row, col)
        turnTimer.cancel()

        if (checkForWin()) {
            handleWin()
        } else if (moveCount == 9) {
            handleDraw()
        } else {
            playerXTurn = !playerXTurn
            updateStatus()
            startTurnTimer()
        }
    }

    private fun updateButton(button: Button, row: Int, col: Int) {
        val player = if (playerXTurn) PLAYER_X else PLAYER_O
        board[row][col] = player

        button.apply {
            text = if (playerXTurn) "X" else "O"
            setTextColor(ContextCompat.getColor(context,
                if (playerXTurn) android.R.color.holo_blue_dark
                else android.R.color.holo_red_dark
            ))
        }
    }

    private fun checkForWin(): Boolean {
        val currentPlayer = if (playerXTurn) PLAYER_X else PLAYER_O

        WINNING_SEQUENCES.forEach { sequence ->
            if (sequence.all { position ->
                    board[position / 3][position % 3] == currentPlayer
                }) {
                highlightWinningSequence(sequence)
                return true
            }
        }
        return false
    }

    private fun highlightWinningSequence(sequence: IntArray) {
        sequence.forEach { position ->
            buttons[position].apply {
                setBackgroundColor(ContextCompat.getColor(this@MainActivity, android.R.color.holo_green_light))
                startAnimation(AnimationUtils.loadAnimation(this@MainActivity, R.anim.win_animation))
            }
        }
    }

    private fun handleWin() {
        gameActive = false
        turnTimer.cancel()

        if (playerXTurn) {
            playerXScore++
            currentWinStreak++
        } else {
            playerOScore++
            currentWinStreak = 0
        }

        if (currentWinStreak > bestWinStreak) {
            bestWinStreak = currentWinStreak
            showToast("¡Nuevo récord de racha!")
        }

        val winner = if (playerXTurn) "X" else "O"
        tvStatus.text = "¡Jugador $winner gana!"

        updateScoreDisplay()
        updateWinStreakDisplay()
        saveGameStats()

        showGameOverDialog("¡Jugador $winner gana!\nPuntuación: X: $playerXScore - O: $playerOScore\nRacha actual: $currentWinStreak")
    }

    private fun handleDraw() {
        gameActive = false
        turnTimer.cancel()
        currentWinStreak = 0
        tvStatus.text = "¡Empate!"
        updateWinStreakDisplay()
        showGameOverDialog("¡Empate!\nPuntuación: X: $playerXScore - O: $playerOScore")
    }

    private fun showGameOverDialog(message: String) {
        Handler(Looper.getMainLooper()).postDelayed({
            AlertDialog.Builder(this)
                .setTitle("Fin del juego")
                .setMessage(message)
                .setPositiveButton("Nuevo juego") { _, _ -> resetGame() }
                .setNegativeButton("Reiniciar puntuación") { _, _ ->
                    resetScores()
                    resetGame()
                }
                .setNeutralButton("Ajustes") { _, _ -> showSettingsDialog() }
                .setCancelable(false)
                .show()
        }, 500)
    }

    private fun showSettingsDialog() {
        val options = arrayOf("10 segundos", "15 segundos", "20 segundos", "30 segundos")
        AlertDialog.Builder(this)
            .setTitle("Ajustes de juego")
            .setItems(options) { _, which ->
                timePerTurn = when (which) {
                    0 -> 10000L
                    1 -> 15000L
                    2 -> 20000L
                    3 -> 30000L
                    else -> 10000L
                }
                resetGame()
            }
            .show()
    }

    private fun resetScores() {
        playerXScore = 0
        playerOScore = 0
        currentWinStreak = 0
        bestWinStreak = 0
        updateScoreDisplay()
        updateWinStreakDisplay()
        saveGameStats()
    }

    private fun resetGame() {
        turnTimer.cancel()
        buttons.forEach { button ->
            button.apply {
                text = ""
                setBackgroundColor(ContextCompat.getColor(context, android.R.color.white))
                startAnimation(AnimationUtils.loadAnimation(this@MainActivity, R.anim.reset_animation))
            }
        }
        initializeBoard()
    }

    private fun updateStatus() {
        tvStatus.text = if (playerXTurn) "Turno: Jugador X" else "Turno: Jugador O"
    }

    private fun updateScoreDisplay() {
        tvScore.text = "X: $playerXScore - O: $playerOScore"
    }

    private fun updateWinStreakDisplay() {
        tvWinStreak.text = "Racha: $currentWinStreak | Mejor: $bestWinStreak"
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer.release()
        if (::turnTimer.isInitialized) {
            turnTimer.cancel()
        }
    }
}